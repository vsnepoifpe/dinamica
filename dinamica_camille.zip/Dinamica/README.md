# dinamica
Repositório para dinâmica da disciplina de PADS
