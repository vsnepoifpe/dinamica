package main;

import java.util.Scanner;

// Calculadora básica com as 4 operações
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("===== Calculadora =====");
            System.out.println("1. Adicao");
            System.out.println("2. Subtracao");
            System.out.println("3. Multiplicacao");
            System.out.println("4. Divisao");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opcao: ");
            int opcao = scanner.nextInt();

            if (opcao >= 1 && opcao <= 4) {
                if (opcao == 2) { // Lógica específica para subtração
                    System.out.print("Quantos números você deseja subtrair? ");
                    int quantidade = scanner.nextInt();

                    if (quantidade < 2) {
                        System.out.println("Você deve inserir pelo menos 2 números para realizar a subtração.");
                        continue;
                    }

                    double resultado = 0;

                    System.out.print("Digite o primeiro número: ");
                    resultado = scanner.nextDouble();

                    for (int i = 1; i < quantidade; i++) {
                        System.out.print("Digite o próximo número: ");
                        double num = scanner.nextDouble();
                        resultado -= num;
                    }

                    System.out.println("Resultado da subtração: " + resultado);

                } else {
                    System.out.print("Digite o primeiro número: ");
                    double num1 = scanner.nextDouble();

                    System.out.print("Digite o segundo número: ");
                    double num2 = scanner.nextDouble();

                    switch (opcao) {
                        case 1:
                            // Implementar lógica de soma aqui
                            break;
                        case 3:
                            // Implementar lógica de multiplicação aqui
                            break;
                        case 4:
                            // Implementar lógica de divisão aqui
                            break;
                    }
                }

            } else if (opcao == 5) {
                running = false;
                System.out.println("Saindo...");
            } else {
                System.out.println("Opção inválida! Tente novamente.");
            }

            System.out.println();
        }

        scanner.close();
    }
}
